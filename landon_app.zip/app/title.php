<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class title extends readeOnly
{
    public $title=['Mr','Ms','Mrs','Dr','Mx','Professor'];
//extends readeOnly
}
