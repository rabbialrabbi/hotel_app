<?php /* D:\LocalHost\htdocs\Project\landon_app\resources\views/reservation/reservations.blade.php */ ?>
<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="medium-12 large-12 columns">
            <h4>Reservations</h4>

            <table class="stack">
                <thead>
                <tr>
                    <th width="200">ROOM</th>
                    <th width="200">Name</th>
                    <th width="200">DATES</th>
                    <th width="200">Action</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>